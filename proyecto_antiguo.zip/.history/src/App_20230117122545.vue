<script></script>

<template>
  <div></div>
</template>

<style>
body {
  display: flex;
  justify-content: center;
  font-family: "montserrat", sans-serif;
  min-height: 100vh;
}

#app {
  width: 100%;
  max-width: 900px;
  margin: 0;
  padding: 0;

  font-weight: normal;
}
</style>
