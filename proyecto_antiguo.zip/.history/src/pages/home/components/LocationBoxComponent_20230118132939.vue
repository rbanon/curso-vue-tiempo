<template>
  <div></div>
</template>

<script>
  export default {
    name: 'location-box',
    created() {},
    data() {
      return {};
    },
    props: {},
    methods: {},
  };
</script>

/* <style lang="scss" scoped></style> */
