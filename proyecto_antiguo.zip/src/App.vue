<script>
  import { weatherApi } from './api/weather-api';
  import { API_KEY, API_LANG } from './api/config';
  import SearchBoxComponent from './pages/home/components/SearchBoxComponent.vue';
  import LocationBoxComponent from './pages/home/components/LocationBoxComponent.vue';

  export default {
    components: { SearchBoxComponent, LocationBoxComponent },
    name: 'app',

    data() {
      return {
        query: '',
        weather: {},
        weatherCity: '',
        weatherCountry: '',
        weatherTemp: '',
        weatherDesc: '',
        isLoaded: false,
      };
    },

    methods: {
      async fetchWeather(event) {
        try {
          const resp = await weatherApi.get(`?q=${event?.data}&appid=${API_KEY}&lang=${API_LANG}`);

          this.weather = resp.data;
          this.weatherCity = resp.data.name;
          this.weatherCountry = resp.data.sys.country;
          var tempC = (resp.data.main.temp - 273.15).toFixed(2);
          this.weatherTemp = `${tempC}ºC`;
          const description = resp.data.weather[0].description;
          this.weatherDesc = description.charAt(0).toUpperCase() + description.slice(1);
          this.isLoaded = true;

          console.log(resp.data);
          console.log(resp.data.name); // Nombre
          console.log(resp.data.sys.county); // País
          console.log(resp.data.main.temp); // Temperatura
          console.log(resp.data.weather[0].description); // Descripción

          console.log(this.isLoaded);
        } catch (error) {
          console.error(error);
        }
      },
      async resultBuilder() {
        const resp = await weatherApi.get(`?q=${this.query}&appid=${API_KEY}&lang=${API_LANG}`);

        return (this.weather = resp.data);
      },
      dateBuilder() {
        let day = new Date();

        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };

        return day.toLocaleDateString('es-ES', options);
      },
    },
  };
</script>

<template>
  <div class="main-container" :class="weather?.main && weather?.main.temp > 16 ? 'warm' : 'cold'">
    <main>
      <SearchBoxComponent @call-api="fetchWeather" />
      <div class="weather-wrap" v-if="weather?.main">
        <LocationBoxComponent :weather="weather" />
        <div class="weather-box">
          <div class="temp">
            <h1>{{ (weather.main.temp - 273.15).toFixed(2) }}</h1>
          </div>
          <div class="weather">
            <h3>{{ weather[0].description }}</h3>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<style>
  body {
    display: flex;

    justify-content: center;

    font-family: 'montserrat', sans-serif;

    min-height: 100vh;

    margin: 0;
  }

  #app {
    width: 100%;

    max-width: 900px;

    margin: 0;

    padding: 0;

    font-weight: normal;
  }

  .main-container {
    width: 100%;

    height: 100%;

    background-image: url('./assets/warm-bg.jpg');

    background-size: cover;

    background-position: bottom;

    padding: 2%;
  }

  .location-box .location,
  .location-box .weather,
  .location-box .temp {
    color: #fff;

    font-size: 32px;

    font-weight: 500;

    text-align: center;

    text-shadow: 1px 3px rgba(0, 0, 0, 0.25);
  }

  .location-box .date {
    color: #fff;

    font-size: 20px;

    font-weight: 300;

    font-style: italic;

    text-align: center;
  }

  weather-box {
    text-align: center;
  }

  .weather-box .temp {
    display: inline-block;

    padding: 10px 25px;

    color: #fff;

    font-size: 102px;

    font-weight: 900;

    text-shadow: 3px 6px rgba(0, 0, 0, 0.25);

    background-color: rgba(255, 255, 255, 0.25);

    border-radius: 16px;

    margin: 30px 0px;

    box-shadow: 3px 6px rgba(0, 0, 0, 0.25);
  }
  .weather-box .weather {
    color: #fff;

    font-size: 48px;

    font-weight: 700;

    font-style: italic;

    text-shadow: 3px 6px rgba(0, 0, 0, 0.25);
  }

  .weather-box {
    text-align: center;
  }

  .weather-box .temp {
    display: inline-block;

    padding: 10px 25px;

    color: #fff;

    font-size: 102px;

    font-weight: 900;

    text-shadow: 3px 6px rgba(0, 0, 0, 0.25);

    background-color: rgba(255, 255, 255, 0.25);

    border-radius: 16px;

    margin: 30px 0px;

    box-shadow: 3px 6px rgba(0, 0, 0, 0.25);
  }

  .weather-box .weather {
    color: #fff;

    font-size: 48px;

    font-weight: 700;

    font-style: italic;

    text-shadow: 3px 6px rgba(0, 0, 0, 0.25);
  }
</style>
