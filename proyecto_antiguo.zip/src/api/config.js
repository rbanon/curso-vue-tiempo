export const API_KEY = '5ad4cc52b04e6c53ee69b3229a9f1cbd';
export const API_LANG = 'es';
